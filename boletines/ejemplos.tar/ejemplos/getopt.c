#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void main(int argc, char *argv[]) {
    int opt, flag, n;
    flag = n = 0;
    optind = 1;
    while ((opt = getopt(argc, argv, "fn:h")) != -1) {
        switch (opt) {
            case 'f':
                flag = 1;
                break;
            case 'n':
                n = atoi(optarg);
                break;
            default:
                fprintf(stderr, "Usage: %s [-f] [-n NUM]\n", argv[0]);
                exit(EXIT_FAILURE);
        }
    }
    for(int i = optind; i < argc; i++) printf("%s\n", argv[i]);
}
