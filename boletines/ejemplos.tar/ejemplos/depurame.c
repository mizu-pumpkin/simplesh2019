#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char** inicializa()
{
    char** tmp;
    int i;

    tmp = malloc(2000 * sizeof (char *));
    for(i = 0; i < 20000; i++)
        tmp[i] = 0;

    return tmp;
}

void copia(char** buffer)
{
    strcpy(buffer[0], "ASO");
}

int main(void)
{
    char** buffer;

    buffer = inicializa();
    copia(buffer);
    printf("%s\n", buffer[0]);

    return EXIT_SUCCESS;
}
